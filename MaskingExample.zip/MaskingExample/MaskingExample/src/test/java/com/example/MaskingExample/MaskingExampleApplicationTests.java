package com.example.MaskingExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaskingExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
