package com.example.MaskingExample.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.MaskingExample.Entity.Employee;
import com.example.MaskingExample.Service.EmployeeService;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@PostMapping("/postEmpDetails")
	public String postMethod(@RequestBody  Employee employee) {
		employeeService.postEmployeeDetails(employee);
		
		return "Employee  Details are updated";
		
	}

	@GetMapping("/allEmpData")
	public List<Employee> getAllEmpDetails(){
		return employeeService.getEmpDetails();
		
	}
	
	@GetMapping("/allEmp/{id}")
	public Employee getDataById(@PathVariable int id) {
		return employeeService.getEmpDataById(id);
		
	}
}
