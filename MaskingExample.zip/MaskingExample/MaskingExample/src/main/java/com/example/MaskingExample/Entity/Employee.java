package com.example.MaskingExample.Entity;

import com.example.MaskingExample.Encryption.MaskData;

import jakarta.annotation.Generated;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int id, String aadharNo, String name, String title, String teamName, String location) {
		super();
		this.id = id;
		this.aadharNo = aadharNo;
		Name = name;
		this.title = title;
		this.teamName = teamName;
		this.location = location;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", aadharNo=" + aadharNo + ", Name=" + Name + ", title=" + title + ", teamName="
				+ teamName + ", location=" + location + "]";
	}
	@MaskData
	private String aadharNo;
	private String Name;
	@MaskData
	
	
	private String title;
	private String teamName;
	private String location;

}
