package com.example.MaskingExample.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.MaskingExample.Entity.Employee;
import com.example.MaskingExample.Repository.EmployeeRepo;

@Service
public class EmployeeService {
@Autowired
	EmployeeRepo employeeRep;

public Employee postEmployeeDetails(Employee employee) {
	return employeeRep.save(employee);
	
	
}


public List<Employee> postEmployeeDetails(List<Employee> employee){
	return employeeRep.saveAll(employee);
	
	}


public List<Employee> getEmpDetails() {
	// TODO Auto-generated method stub
	return (List<Employee>) employeeRep.findAll();
}


public Employee getEmpDataById(int id) {
	
	return employeeRep.findById(id).orElse(null);
}
}