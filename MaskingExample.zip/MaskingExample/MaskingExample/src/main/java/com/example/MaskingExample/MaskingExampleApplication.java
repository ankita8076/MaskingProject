package com.example.MaskingExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaskingExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaskingExampleApplication.class, args);
	}

}
